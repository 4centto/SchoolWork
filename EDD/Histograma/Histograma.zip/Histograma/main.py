arreglo = []

#Primero se registra el cuento
with open("cuento.txt", encoding="utf-8") as file:
    for linea in file:
        palabra = linea.split()
        for i in palabra:
            arreglo.append(i)

#Ahora se hace el conteo de cada palabra
for palabra in arreglo:
    contador = 0
    for i in range(len(arreglo)):
        if palabra == arreglo[i]:
            contador += 1

    print(" ->", palabra, ":", contador)
